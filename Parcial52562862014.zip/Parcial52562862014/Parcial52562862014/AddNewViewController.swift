//
//  AddNewViewController.swift
//  Parcial52562862014
//
// Aureliano Martinez
//  2562862014
//

import UIKit




protocol BookStoreDelegate {
    func newBook(_ controller: AnyObject, newBook: Book)
    func editBook(_ controller: AnyObject, editBook: Book)
    func deleteBook(_ controller: AnyObject)
}


class AddNewViewController: UIViewController {
    var book = Book()
    var delegate: BookStoreDelegate?
    var read = false
    var editBook = false
    
    @IBOutlet weak var titleText: UITextField!
    @IBOutlet weak var authorText: UITextField!
    @IBOutlet weak var pagesText: UITextField!
    @IBOutlet weak var switchOutlet: UISwitch!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if editBook == true {
            self.title = "Edit Book"
            titleText.text = book.title
            authorText.text = book.author
            
            
            
        }
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    @IBAction func saveBookAction(_ sender: UIButton) {
        book.title = titleText.text!
        book.author = authorText.text!
       
        
        if (editBook) {
            delegate!.editBook(self, editBook:book)
        }
        else {
            delegate!.newBook(self, newBook:book)
        }
        
        
        
    }
    
}
