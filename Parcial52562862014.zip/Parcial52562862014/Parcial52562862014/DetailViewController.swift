//
//  DetailViewController.swift
//  Parcial52562862014
//
// Aureliano Martinez
//  2562862014

import UIKit

class DetailViewController: UIViewController {

    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var Precio: UILabel!
    @IBOutlet weak var pagesOutlet: UILabel!
    
    
    var delegate: BookStoreDelegate? = nil
    
    var myBook = Book()
    
    
    
    
    func configureView() {
        if let detail = self.detailItem {
            myBook = detail
            titleLabel.text = myBook.title
            authorLabel.text = myBook.author
                       
            
        }
    }
    /*
     func configureView() {
     
     if let detail: AnyObject = self.detailItem {
     
     let myBook = detail as! Book
     titleLabel.text=myBook.title
     authorLabel.text=myBook.author
     Precio.text=myBook.precio
     
     //  genre.text=myBook.genero
     descriptionTextView.text=myBook.description
     
     
     }
     
     // Update the user interface for the detail item.
     
     }
     */
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "editDetail" {
            let vc = segue.destination as! AddNewViewController
            vc.delegate = delegate
            vc.editBook = true
            vc.book = myBook
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.configureView()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    var detailItem: Book? {
        didSet {
            // Update the view.
            // self.configureView()
        }
    }
    
    
    @IBAction func deleteBookAction(_ sender: UIBarButtonItem) {
        let alertController = UIAlertController(title: "Warning", message:" Delete this book?",
                                                preferredStyle: .alert)
        let noAction = UIAlertAction(title: "No", style: .cancel) { (action) in
            print("Cancel")
        }
        alertController.addAction(noAction)
        
        let yesAction = UIAlertAction(title: "Yes", style: .destructive) { (action) in
            self.delegate!.deleteBook(self)
        }
        alertController.addAction(yesAction)
        
        present(alertController, animated: false, completion: nil)
    }
    
    
}


