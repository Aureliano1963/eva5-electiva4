//
//  Listprogram+CoreDataClass.swift
//  Parcial52562862014
//
// Aureliano Martinez
//  2562862014
//

class BookStore {
    var theBookStore: [Book] = []
    
    init() {
        
        var newBook=Book()
        newBook.title=" Pyton "
        newBook.author=" Windows, linux, mac"
        
        
        theBookStore.append(newBook)
        
        newBook=Book()
        newBook.title=" C# "
        newBook.author=" Windows, linux"
        
        theBookStore.append(newBook)
        
        newBook=Book()
        newBook.title=" C++"
        newBook.author=" Windows, linux "
        
        theBookStore.append(newBook)
        
        newBook=Book()
        newBook.title=" Java "
        newBook.author=" Windows, linux "
        
        theBookStore.append(newBook)
    }
    
}
