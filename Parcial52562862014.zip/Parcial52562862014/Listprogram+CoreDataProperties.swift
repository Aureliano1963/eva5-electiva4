//
//  Listprogram+CoreDataProperties.swift
//  Parcial52562862014
//
// Aureliano Martinez
//  2562862014
//

import Foundation

class Book {
    var title:String=""
    var author:String=""
    var pages: Int = 0
   
}
